﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Documentation
{

    class Program
    {

        static void Main()
        {
            // No actual code in this project (yet?)
        }

    }

}
