//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SleepTimer.rc
//
#define IDS_PROJNAME                    100
#define IDR_SLEEPTIMERCTRL              103
#define IDD_SLEEPTIMERCTRL              104
#define IDC_SLEEP                       202
#define IDC_ACTION                      204
#define IDC_FADE_VOLUME                 205
#define IDC_DURATION                    206
#define IDI_SLEEP                       412

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         207
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
