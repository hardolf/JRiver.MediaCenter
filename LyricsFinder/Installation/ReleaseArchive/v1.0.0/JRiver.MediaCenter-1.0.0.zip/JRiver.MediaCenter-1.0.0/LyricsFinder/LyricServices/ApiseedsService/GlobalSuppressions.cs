﻿// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0059:Value assigned to symbol is never used", Justification = "<Pending>", Scope = "member", Target = "~M:MediaCenter.LyricsFinder.Model.LyricServices.ApiseedsService.Process(MediaCenter.LyricsFinder.Model.McRestService.McMplItem,System.Boolean)~MediaCenter.LyricsFinder.Model.LyricServices.AbstractLyricService")]// This file is used by Code Analysis to maintain SuppressMessage 
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "<Pending>", Scope = "member", Target = "~M:MediaCenter.LyricsFinder.Model.LyricServices.Test.UnitTest.TestMethod02")]