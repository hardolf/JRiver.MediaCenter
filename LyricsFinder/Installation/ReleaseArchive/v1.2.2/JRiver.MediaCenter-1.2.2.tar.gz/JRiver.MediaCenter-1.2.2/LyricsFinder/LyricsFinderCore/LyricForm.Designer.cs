﻿namespace MediaCenter.LyricsFinder
{
    partial class LyricForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                    components.Dispose();

                if (_cancellationTokenSource != null)
                    _cancellationTokenSource.Dispose();

                if (_searchForm != null)
                    _searchForm.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LyricFormToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ArtistTextBox = new System.Windows.Forms.TextBox();
            this.AlbumTextBox = new System.Windows.Forms.TextBox();
            this.TrackTextBox = new System.Windows.Forms.TextBox();
            this.LyricFormTrackBar = new System.Windows.Forms.TrackBar();
            this.SearchButton = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Button();
            this.LyricFormToolStripContainer = new System.Windows.Forms.ToolStripContainer();
            this.LyricFormPanel = new System.Windows.Forms.Panel();
            this.LyricParmsPanel = new System.Windows.Forms.TableLayoutPanel();
            this.ArtistLabel = new System.Windows.Forms.Label();
            this.AlbumLabel = new System.Windows.Forms.Label();
            this.TrackLabel = new System.Windows.Forms.Label();
            this.LyricFormStatusStrip = new System.Windows.Forms.StatusStrip();
            this.LyricFormStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.LyricFormFoundStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.LyricTextBox = new System.Windows.Forms.TextBox();
            this.LyricFormMenuStrip = new System.Windows.Forms.MenuStrip();
            this.EditMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditUndoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditSeparator0 = new System.Windows.Forms.ToolStripSeparator();
            this.EditSelectAllMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditCutMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditCopyMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditPasteMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditDeleteMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.EditProperCaseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditTitleCaseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditLowerCaseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditUpperCaseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditSentenceCaseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.EditSpellCheckMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolsSearchMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpHelpMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.LyricFormTrackBar)).BeginInit();
            this.LyricFormToolStripContainer.ContentPanel.SuspendLayout();
            this.LyricFormToolStripContainer.TopToolStripPanel.SuspendLayout();
            this.LyricFormToolStripContainer.SuspendLayout();
            this.LyricFormPanel.SuspendLayout();
            this.LyricParmsPanel.SuspendLayout();
            this.LyricFormStatusStrip.SuspendLayout();
            this.LyricFormMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // ArtistTextBox
            // 
            this.ArtistTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ArtistTextBox.Location = new System.Drawing.Point(3, 18);
            this.ArtistTextBox.Multiline = true;
            this.ArtistTextBox.Name = "ArtistTextBox";
            this.ArtistTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ArtistTextBox.Size = new System.Drawing.Size(121, 43);
            this.ArtistTextBox.TabIndex = 1;
            this.LyricFormToolTip.SetToolTip(this.ArtistTextBox, "Artist name, change to refine search");
            // 
            // AlbumTextBox
            // 
            this.AlbumTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AlbumTextBox.Location = new System.Drawing.Point(130, 18);
            this.AlbumTextBox.Multiline = true;
            this.AlbumTextBox.Name = "AlbumTextBox";
            this.AlbumTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.AlbumTextBox.Size = new System.Drawing.Size(122, 43);
            this.AlbumTextBox.TabIndex = 1;
            this.LyricFormToolTip.SetToolTip(this.AlbumTextBox, "Album name, change to refine search");
            // 
            // TrackTextBox
            // 
            this.TrackTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TrackTextBox.Location = new System.Drawing.Point(258, 18);
            this.TrackTextBox.Multiline = true;
            this.TrackTextBox.Name = "TrackTextBox";
            this.TrackTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TrackTextBox.Size = new System.Drawing.Size(123, 43);
            this.TrackTextBox.TabIndex = 1;
            this.LyricFormToolTip.SetToolTip(this.TrackTextBox, "Track title, change to refine search");
            // 
            // LyricFormTrackBar
            // 
            this.LyricFormTrackBar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.LyricFormTrackBar.Location = new System.Drawing.Point(3, 467);
            this.LyricFormTrackBar.Maximum = 0;
            this.LyricFormTrackBar.Name = "LyricFormTrackBar";
            this.LyricFormTrackBar.Size = new System.Drawing.Size(289, 45);
            this.LyricFormTrackBar.TabIndex = 6;
            this.LyricFormToolTip.SetToolTip(this.LyricFormTrackBar, "Switch between all the lyrics search results (Arrows)");
            this.LyricFormTrackBar.Visible = false;
            this.LyricFormTrackBar.Scroll += new System.EventHandler(this.LyricFormTrackBar_ScrollAsync);
            // 
            // SearchButton
            // 
            this.SearchButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchButton.Location = new System.Drawing.Point(200, 477);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(75, 23);
            this.SearchButton.TabIndex = 7;
            this.SearchButton.Text = "&Search...";
            this.LyricFormToolTip.SetToolTip(this.SearchButton, "Search for more lyrics");
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Visible = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_ClickAsync);
            // 
            // CloseButton
            // 
            this.CloseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CloseButton.Location = new System.Drawing.Point(298, 477);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(74, 23);
            this.CloseButton.TabIndex = 8;
            this.CloseButton.Text = "&Close (Esc)";
            this.LyricFormToolTip.SetToolTip(this.CloseButton, "Close the window (Esc)");
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_ClickAsync);
            // 
            // LyricFormToolStripContainer
            // 
            // 
            // LyricFormToolStripContainer.ContentPanel
            // 
            this.LyricFormToolStripContainer.ContentPanel.Controls.Add(this.LyricFormPanel);
            this.LyricFormToolStripContainer.ContentPanel.Size = new System.Drawing.Size(384, 537);
            this.LyricFormToolStripContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LyricFormToolStripContainer.Location = new System.Drawing.Point(0, 0);
            this.LyricFormToolStripContainer.Name = "LyricFormToolStripContainer";
            this.LyricFormToolStripContainer.Size = new System.Drawing.Size(384, 561);
            this.LyricFormToolStripContainer.TabIndex = 0;
            this.LyricFormToolStripContainer.Text = "toolStripContainer1";
            // 
            // LyricFormToolStripContainer.TopToolStripPanel
            // 
            this.LyricFormToolStripContainer.TopToolStripPanel.Controls.Add(this.LyricFormMenuStrip);
            // 
            // LyricFormPanel
            // 
            this.LyricFormPanel.Controls.Add(this.LyricParmsPanel);
            this.LyricFormPanel.Controls.Add(this.LyricFormStatusStrip);
            this.LyricFormPanel.Controls.Add(this.LyricFormTrackBar);
            this.LyricFormPanel.Controls.Add(this.SearchButton);
            this.LyricFormPanel.Controls.Add(this.LyricTextBox);
            this.LyricFormPanel.Controls.Add(this.CloseButton);
            this.LyricFormPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LyricFormPanel.Location = new System.Drawing.Point(0, 0);
            this.LyricFormPanel.Name = "LyricFormPanel";
            this.LyricFormPanel.Size = new System.Drawing.Size(384, 537);
            this.LyricFormPanel.TabIndex = 1;
            // 
            // LyricParmsPanel
            // 
            this.LyricParmsPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LyricParmsPanel.ColumnCount = 3;
            this.LyricParmsPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.LyricParmsPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.LyricParmsPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.LyricParmsPanel.Controls.Add(this.ArtistLabel, 0, 0);
            this.LyricParmsPanel.Controls.Add(this.AlbumLabel, 1, 0);
            this.LyricParmsPanel.Controls.Add(this.TrackLabel, 2, 0);
            this.LyricParmsPanel.Controls.Add(this.ArtistTextBox, 0, 1);
            this.LyricParmsPanel.Controls.Add(this.AlbumTextBox, 1, 1);
            this.LyricParmsPanel.Controls.Add(this.TrackTextBox, 2, 1);
            this.LyricParmsPanel.Location = new System.Drawing.Point(0, 4);
            this.LyricParmsPanel.Name = "LyricParmsPanel";
            this.LyricParmsPanel.RowCount = 2;
            this.LyricParmsPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.LyricParmsPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.LyricParmsPanel.Size = new System.Drawing.Size(384, 64);
            this.LyricParmsPanel.TabIndex = 10;
            // 
            // ArtistLabel
            // 
            this.ArtistLabel.AutoSize = true;
            this.ArtistLabel.Location = new System.Drawing.Point(3, 0);
            this.ArtistLabel.Name = "ArtistLabel";
            this.ArtistLabel.Size = new System.Drawing.Size(30, 13);
            this.ArtistLabel.TabIndex = 0;
            this.ArtistLabel.Text = "Artist";
            // 
            // AlbumLabel
            // 
            this.AlbumLabel.AutoSize = true;
            this.AlbumLabel.Location = new System.Drawing.Point(130, 0);
            this.AlbumLabel.Name = "AlbumLabel";
            this.AlbumLabel.Size = new System.Drawing.Size(36, 13);
            this.AlbumLabel.TabIndex = 0;
            this.AlbumLabel.Text = "Album";
            // 
            // TrackLabel
            // 
            this.TrackLabel.AutoSize = true;
            this.TrackLabel.Location = new System.Drawing.Point(258, 0);
            this.TrackLabel.Name = "TrackLabel";
            this.TrackLabel.Size = new System.Drawing.Size(58, 13);
            this.TrackLabel.TabIndex = 0;
            this.TrackLabel.Text = "Track Title";
            // 
            // LyricFormStatusStrip
            // 
            this.LyricFormStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LyricFormStatusLabel,
            this.LyricFormFoundStatusLabel});
            this.LyricFormStatusStrip.Location = new System.Drawing.Point(0, 515);
            this.LyricFormStatusStrip.Name = "LyricFormStatusStrip";
            this.LyricFormStatusStrip.Size = new System.Drawing.Size(384, 22);
            this.LyricFormStatusStrip.TabIndex = 9;
            this.LyricFormStatusStrip.Text = "statusStrip1";
            // 
            // LyricFormStatusLabel
            // 
            this.LyricFormStatusLabel.Name = "LyricFormStatusLabel";
            this.LyricFormStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // LyricFormFoundStatusLabel
            // 
            this.LyricFormFoundStatusLabel.Name = "LyricFormFoundStatusLabel";
            this.LyricFormFoundStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // LyricTextBox
            // 
            this.LyricTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LyricTextBox.Location = new System.Drawing.Point(3, 74);
            this.LyricTextBox.Multiline = true;
            this.LyricTextBox.Name = "LyricTextBox";
            this.LyricTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.LyricTextBox.Size = new System.Drawing.Size(378, 387);
            this.LyricTextBox.TabIndex = 5;
            this.LyricTextBox.TextChanged += new System.EventHandler(this.LyricTextBox_TextChangedAsync);
            this.LyricTextBox.Enter += new System.EventHandler(this.LyricTextBox_EnterAsync);
            this.LyricTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LyricTextBox_KeyDownAsync);
            this.LyricTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LyricTextBox_KeyPressAsync);
            this.LyricTextBox.Leave += new System.EventHandler(this.LyricTextBox_LeaveAsync);
            // 
            // LyricFormMenuStrip
            // 
            this.LyricFormMenuStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.LyricFormMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EditMenuItem,
            this.ToolsMenuItem,
            this.HelpMenuItem});
            this.LyricFormMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.LyricFormMenuStrip.Name = "LyricFormMenuStrip";
            this.LyricFormMenuStrip.Size = new System.Drawing.Size(384, 24);
            this.LyricFormMenuStrip.TabIndex = 0;
            this.LyricFormMenuStrip.Text = "menuStrip1";
            // 
            // EditMenuItem
            // 
            this.EditMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EditUndoMenuItem,
            this.EditSeparator0,
            this.EditSelectAllMenuItem,
            this.EditCutMenuItem,
            this.EditCopyMenuItem,
            this.EditPasteMenuItem,
            this.EditDeleteMenuItem,
            this.EditSeparator1,
            this.EditProperCaseMenuItem,
            this.EditTitleCaseMenuItem,
            this.EditLowerCaseMenuItem,
            this.EditUpperCaseMenuItem,
            this.EditSentenceCaseMenuItem,
            this.EditSeparator2,
            this.EditSpellCheckMenuItem});
            this.EditMenuItem.Name = "EditMenuItem";
            this.EditMenuItem.Size = new System.Drawing.Size(39, 20);
            this.EditMenuItem.Text = "&Edit";
            this.EditMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditUndoMenuItem
            // 
            this.EditUndoMenuItem.Name = "EditUndoMenuItem";
            this.EditUndoMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.EditUndoMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditUndoMenuItem.Text = "&Undo";
            this.EditUndoMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditSeparator0
            // 
            this.EditSeparator0.Name = "EditSeparator0";
            this.EditSeparator0.Size = new System.Drawing.Size(231, 6);
            // 
            // EditSelectAllMenuItem
            // 
            this.EditSelectAllMenuItem.Name = "EditSelectAllMenuItem";
            this.EditSelectAllMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.EditSelectAllMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditSelectAllMenuItem.Text = "Select &all";
            this.EditSelectAllMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditCutMenuItem
            // 
            this.EditCutMenuItem.Name = "EditCutMenuItem";
            this.EditCutMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.EditCutMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditCutMenuItem.Text = "Cut";
            this.EditCutMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditCopyMenuItem
            // 
            this.EditCopyMenuItem.Name = "EditCopyMenuItem";
            this.EditCopyMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.EditCopyMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditCopyMenuItem.Text = "Copy";
            this.EditCopyMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditPasteMenuItem
            // 
            this.EditPasteMenuItem.Name = "EditPasteMenuItem";
            this.EditPasteMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.EditPasteMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditPasteMenuItem.Text = "Paste";
            this.EditPasteMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditDeleteMenuItem
            // 
            this.EditDeleteMenuItem.Name = "EditDeleteMenuItem";
            this.EditDeleteMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.EditDeleteMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditDeleteMenuItem.Text = "Delete";
            this.EditDeleteMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditSeparator1
            // 
            this.EditSeparator1.Name = "EditSeparator1";
            this.EditSeparator1.Size = new System.Drawing.Size(231, 6);
            // 
            // EditProperCaseMenuItem
            // 
            this.EditProperCaseMenuItem.Name = "EditProperCaseMenuItem";
            this.EditProperCaseMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.P)));
            this.EditProperCaseMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditProperCaseMenuItem.Text = "&Proper case selection";
            this.EditProperCaseMenuItem.ToolTipText = "In every word the first letter is capitalized";
            this.EditProperCaseMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditTitleCaseMenuItem
            // 
            this.EditTitleCaseMenuItem.Name = "EditTitleCaseMenuItem";
            this.EditTitleCaseMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.T)));
            this.EditTitleCaseMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditTitleCaseMenuItem.Text = "&Title case selection";
            this.EditTitleCaseMenuItem.ToolTipText = "In every word the first letter is capitalized,\r\nexcept where word length is less " +
    "than 4";
            this.EditTitleCaseMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditLowerCaseMenuItem
            // 
            this.EditLowerCaseMenuItem.Name = "EditLowerCaseMenuItem";
            this.EditLowerCaseMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.L)));
            this.EditLowerCaseMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditLowerCaseMenuItem.Text = "&Lower case selection";
            this.EditLowerCaseMenuItem.ToolTipText = "All text is in small letters";
            this.EditLowerCaseMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditUpperCaseMenuItem
            // 
            this.EditUpperCaseMenuItem.Name = "EditUpperCaseMenuItem";
            this.EditUpperCaseMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.U)));
            this.EditUpperCaseMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditUpperCaseMenuItem.Text = "&Upper case selection";
            this.EditUpperCaseMenuItem.ToolTipText = "All text is in capital letters";
            this.EditUpperCaseMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditSentenceCaseMenuItem
            // 
            this.EditSentenceCaseMenuItem.Name = "EditSentenceCaseMenuItem";
            this.EditSentenceCaseMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.EditSentenceCaseMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditSentenceCaseMenuItem.Text = "Sentence case selection";
            this.EditSentenceCaseMenuItem.ToolTipText = "In the first word after a newline or period, \r\nthe first letter is capitalized";
            this.EditSentenceCaseMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // EditSeparator2
            // 
            this.EditSeparator2.Name = "EditSeparator2";
            this.EditSeparator2.Size = new System.Drawing.Size(231, 6);
            this.EditSeparator2.Visible = false;
            // 
            // EditSpellCheckMenuItem
            // 
            this.EditSpellCheckMenuItem.Name = "EditSpellCheckMenuItem";
            this.EditSpellCheckMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.EditSpellCheckMenuItem.Size = new System.Drawing.Size(234, 22);
            this.EditSpellCheckMenuItem.Text = "&Spell check selection";
            this.EditSpellCheckMenuItem.Visible = false;
            this.EditSpellCheckMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // ToolsMenuItem
            // 
            this.ToolsMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolsSearchMenuItem});
            this.ToolsMenuItem.Name = "ToolsMenuItem";
            this.ToolsMenuItem.Size = new System.Drawing.Size(47, 20);
            this.ToolsMenuItem.Text = "&Tools";
            this.ToolsMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // ToolsSearchMenuItem
            // 
            this.ToolsSearchMenuItem.Name = "ToolsSearchMenuItem";
            this.ToolsSearchMenuItem.Size = new System.Drawing.Size(109, 22);
            this.ToolsSearchMenuItem.Text = "&Search";
            this.ToolsSearchMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // HelpMenuItem
            // 
            this.HelpMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.HelpHelpMenuItem});
            this.HelpMenuItem.Name = "HelpMenuItem";
            this.HelpMenuItem.Size = new System.Drawing.Size(44, 20);
            this.HelpMenuItem.Text = "&Help";
            this.HelpMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // HelpHelpMenuItem
            // 
            this.HelpHelpMenuItem.Name = "HelpHelpMenuItem";
            this.HelpHelpMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.HelpHelpMenuItem.Size = new System.Drawing.Size(118, 22);
            this.HelpHelpMenuItem.Text = "&Help";
            this.HelpHelpMenuItem.Click += new System.EventHandler(this.MenuItem_ClickAsync);
            // 
            // LyricForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 561);
            this.Controls.Add(this.LyricFormToolStripContainer);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.KeyPreview = true;
            this.MainMenuStrip = this.LyricFormMenuStrip;
            this.MaximumSize = new System.Drawing.Size(800, 1000);
            this.MinimumSize = new System.Drawing.Size(250, 200);
            this.Name = "LyricForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "LyricsForm";
            this.TransparencyKey = System.Drawing.Color.Teal;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.LyricForm_FormClosingAsync);
            this.Load += new System.EventHandler(this.LyricForm_LoadAsync);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LyricForm_KeyDownAsync);
            ((System.ComponentModel.ISupportInitialize)(this.LyricFormTrackBar)).EndInit();
            this.LyricFormToolStripContainer.ContentPanel.ResumeLayout(false);
            this.LyricFormToolStripContainer.TopToolStripPanel.ResumeLayout(false);
            this.LyricFormToolStripContainer.TopToolStripPanel.PerformLayout();
            this.LyricFormToolStripContainer.ResumeLayout(false);
            this.LyricFormToolStripContainer.PerformLayout();
            this.LyricFormPanel.ResumeLayout(false);
            this.LyricFormPanel.PerformLayout();
            this.LyricParmsPanel.ResumeLayout(false);
            this.LyricParmsPanel.PerformLayout();
            this.LyricFormStatusStrip.ResumeLayout(false);
            this.LyricFormStatusStrip.PerformLayout();
            this.LyricFormMenuStrip.ResumeLayout(false);
            this.LyricFormMenuStrip.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip LyricFormToolTip;
        private System.Windows.Forms.ToolStripContainer LyricFormToolStripContainer;
        private System.Windows.Forms.Panel LyricFormPanel;
        private System.Windows.Forms.TableLayoutPanel LyricParmsPanel;
        private System.Windows.Forms.Label ArtistLabel;
        private System.Windows.Forms.Label AlbumLabel;
        private System.Windows.Forms.Label TrackLabel;
        private System.Windows.Forms.TextBox ArtistTextBox;
        private System.Windows.Forms.TextBox AlbumTextBox;
        private System.Windows.Forms.TextBox TrackTextBox;
        private System.Windows.Forms.TrackBar LyricFormTrackBar;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.TextBox LyricTextBox;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.StatusStrip LyricFormStatusStrip;
        private System.Windows.Forms.ToolStripStatusLabel LyricFormStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel LyricFormFoundStatusLabel;
        private System.Windows.Forms.MenuStrip LyricFormMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem EditMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HelpMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HelpHelpMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolsSearchMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditUndoMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditSelectAllMenuItem;
        private System.Windows.Forms.ToolStripSeparator EditSeparator1;
        private System.Windows.Forms.ToolStripMenuItem EditProperCaseMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditTitleCaseMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditLowerCaseMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditUpperCaseMenuItem;
        private System.Windows.Forms.ToolStripSeparator EditSeparator2;
        private System.Windows.Forms.ToolStripMenuItem EditSpellCheckMenuItem;
        private System.Windows.Forms.ToolStripSeparator EditSeparator0;
        private System.Windows.Forms.ToolStripMenuItem EditCutMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditCopyMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditPasteMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditSentenceCaseMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditDeleteMenuItem;
    }
}