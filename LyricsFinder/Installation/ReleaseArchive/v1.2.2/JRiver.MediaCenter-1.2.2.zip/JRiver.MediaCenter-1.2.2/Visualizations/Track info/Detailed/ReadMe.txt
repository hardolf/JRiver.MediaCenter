﻿Original "Detailed" track info files.
Source: http://accessories.jriver.com/mediacenter/mc_data/plugins/787.mjp
Media Center plug-in site: https://yabb.jriver.com/mediacenter/accessories.php
