Please look in the "Documentation" project folder for information.
